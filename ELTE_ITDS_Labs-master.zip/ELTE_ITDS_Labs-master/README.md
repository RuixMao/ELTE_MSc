# Introduction to Data Science Lab Materials
Materials for Practicals of the Introduction to Data Science Course at Eötvös Loránd University - Faculty of Informatics
